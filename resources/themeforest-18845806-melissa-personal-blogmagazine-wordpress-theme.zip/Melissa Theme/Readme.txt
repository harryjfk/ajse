----------------------------

Thank you so much for purchasing this theme!

----------------------------

Folders and Files

----------------------------

Demo Content - demo content (posts, pages, comments, categories, and tags)
|- melissa-demo-data.xml

Documentation - documentation files
|- "assets" folder - contains files for documentation
|- documentation.html - documentation file

Changelog.txt - changelog text file (current theme version: v1.1.6)

melissa.zip - ZIP archive for installation

----------------------------
