Melissa WordPress Theme (v1.1.6)
Flexible, fully responsive & retina ready WordPress theme for your personal blog.

WordPress version: 4.5 or higher
Marketplace: ThemeForest (https://themeforest.net)
Author: BirdwpThemes (https://themeforest.net/user/birdwpthemes)
Live Preview: http://themes.birdwp.com/melissa/
Documentation: http://documentation.birdwp.com/wp-melissa/
